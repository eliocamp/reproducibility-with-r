library(markdown)
library(knitr)
# Not actually needed, but a bug in RStudio (https://github.com/rstudio/rstudio/issues/18199)
# makes it think it is. Quickest workaround is to just satisfy our overlord.
library(stringr)
